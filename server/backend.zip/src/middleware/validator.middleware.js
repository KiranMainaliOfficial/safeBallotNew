export const validate = (schema) => (req, res, next) => {
    const { error, value } = schema.validate(req.body, { stripUnknown: true });
    if (error) {
        return res.status(400).json({ success: false, message: error.message });
    }
    req.body = value;
    next();
};